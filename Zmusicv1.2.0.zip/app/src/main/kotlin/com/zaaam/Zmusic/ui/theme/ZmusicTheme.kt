package com.zaaam.Zmusic.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ── Zmusic Blue Palette ────────────────────────────────────────────────────
private val BluePrimary = Color(0xFF5EB7F6)        // biru muda cerah
private val BlueSecondary = Color(0xFF82CFFF)       // biru langit
private val BlueTertiary = Color(0xFF4FA3E0)        // biru sedang
private val DarkBg = Color(0xFF0F1318)              // hampir hitam
private val DarkSurface = Color(0xFF181C22)         // surface gelap
private val DarkSurfaceVariant = Color(0xFF1E2530)  // card gelap
private val DarkSurfaceContainer = Color(0xFF212830) // mini player
private val OnSurfacePrimary = Color(0xFFEBEFF5)    // teks utama
private val OnSurfaceSecondary = Color(0xFF9EA7B8)  // teks sekunder

private val LightBluePrimary = Color(0xFF2196F3)
private val LightBg = Color(0xFFF5F8FC)
private val LightSurface = Color(0xFFFFFFFF)

private val ZmusicDarkColors = darkColorScheme(
    primary = BluePrimary,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1A3A5C),
    onPrimaryContainer = BlueSecondary,
    secondary = BlueSecondary,
    onSecondary = Color.Black,
    tertiary = BlueTertiary,
    background = DarkBg,
    onBackground = OnSurfacePrimary,
    surface = DarkSurface,
    onSurface = OnSurfacePrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = OnSurfaceSecondary,
    surfaceContainer = DarkSurfaceContainer,
    outline = Color(0xFF2E3640)
)

private val ZmusicLightColors = lightColorScheme(
    primary = LightBluePrimary,
    onPrimary = Color.White,
    background = LightBg,
    onBackground = Color(0xFF1C1B1F),
    surface = LightSurface,
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFE8EDF4),
    onSurfaceVariant = Color(0xFF505868)
)

private val ZmusicTypography = Typography(
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp
    ),
    bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp
    )
)

@Composable
fun ZmusicTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Selalu pakai custom color scheme Zmusic (bukan dynamic)
    val colorScheme = if (darkTheme) ZmusicDarkColors else ZmusicLightColors

    MaterialTheme(
        colorScheme = colorScheme,
        typography = ZmusicTypography,
        content = content
    )
}
