package com.zaaam.Zmusic.di

import android.content.Context
import androidx.room.Room
import com.zaaam.Zmusic.data.LyricsRepository
import com.zaaam.Zmusic.data.local.AppDatabase
import com.zaaam.Zmusic.data.local.PlayHistoryDao
import com.zaaam.Zmusic.data.local.PlaylistDao
import com.zaaam.Zmusic.data.local.SongDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "zmusic.db"
        )
        .addMigrations(AppDatabase.MIGRATION_1_2, AppDatabase.MIGRATION_2_3)
        .build()

    @Provides
    fun provideSongDao(db: AppDatabase): SongDao = db.songDao()

    @Provides
    fun providePlaylistDao(db: AppDatabase): PlaylistDao = db.playlistDao()

    @Provides
    fun providePlayHistoryDao(db: AppDatabase): PlayHistoryDao = db.playHistoryDao()

    @Provides
    @Singleton
    fun provideLyricsRepository(): LyricsRepository = LyricsRepository()
}
