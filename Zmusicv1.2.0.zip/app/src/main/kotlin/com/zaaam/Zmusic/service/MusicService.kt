package com.zaaam.Zmusic.service

import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.zaaam.Zmusic.data.MusicRepository
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.util.QueueManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MusicService : MediaSessionService() {

    @Inject lateinit var queueManager: QueueManager
    @Inject lateinit var repository: MusicRepository

    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var currentPlayJob: Job? = null
    private var isIntentionalSwitch = false
    private var isHandlingError = false
    private var currentSong: Song? = null
    private var currentMood: String? = null       // NEW: mood context untuk record
    private var songStartTime = 0L
    private var accumulatedDuration = 0L
    private var hasRecordedForCurrentSong = false

    override fun onCreate() {
        super.onCreate()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        mediaSession = MediaSession.Builder(this, player).build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && !isIntentionalSwitch) {
                    recordCurrentPlay()
                    playNextAuto()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (isHandlingError) return
                isHandlingError = true
                val song = currentSong ?: run { isHandlingError = false; return }
                val position = player.currentPosition

                serviceScope.launch {
                    try {
                        val freshUrl = repository.getStreamUrl(song.id)
                        player.setMediaItem(MediaItem.fromUri(freshUrl))
                        player.prepare()
                        player.seekTo(position)
                        player.play()
                        isHandlingError = false
                    } catch (e: CancellationException) {
                        isHandlingError = false
                        throw e
                    } catch (_: Exception) {
                        isHandlingError = false
                        playNextAuto()
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    songStartTime = System.currentTimeMillis()
                } else if (songStartTime > 0L) {
                    accumulatedDuration += System.currentTimeMillis() - songStartTime
                    songStartTime = 0L
                }
            }
        })

        serviceScope.launch {
            queueManager.playCommand.collect { request ->
                // FIX: Simpan mood dari PlayRequest
                playSong(request.song, request.userInitiated, request.mood)
            }
        }

        // Observe speed command dari QueueManager
        serviceScope.launch {
            queueManager.speedCommand.collect { speed ->
                player.playbackParameters = PlaybackParameters(speed)
            }
        }
    }

    fun playSong(song: Song, userInitiated: Boolean = false, mood: String? = null) {
        isHandlingError = false
        isIntentionalSwitch = true
        player.stop()

        currentPlayJob?.cancel()
        currentPlayJob = serviceScope.launch {
            try {
                if (currentSong != null && currentSong?.id != song.id) {
                    recordCurrentPlay()
                }

                currentSong = song
                currentMood = mood ?: queueManager.currentMood.value  // NEW: ambil mood
                songStartTime = System.currentTimeMillis()
                accumulatedDuration = 0L
                hasRecordedForCurrentSong = false

                val streamUrl = repository.getStreamUrl(song.id)

                val mediaItem = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .setArtworkUri(Uri.parse(song.thumbnailUrl))
                            .build()
                    )
                    .build()

                player.setMediaItem(mediaItem)
                player.prepare()
                player.play()
                isIntentionalSwitch = false

            } catch (e: CancellationException) {
                isIntentionalSwitch = false
                throw e
            } catch (_: Exception) {
                isIntentionalSwitch = false
                if (!userInitiated) playNextAuto()
            }
        }
    }

    private fun playNextAuto() {
        queueManager.next()?.let { playSong(it, userInitiated = false) }
    }

    private fun recordCurrentPlay() {
        if (hasRecordedForCurrentSong) return
        val song = currentSong ?: return
        var totalDuration = accumulatedDuration
        if (songStartTime > 0L) totalDuration += System.currentTimeMillis() - songStartTime
        if (totalDuration < 10_000) return
        hasRecordedForCurrentSong = true
        val mood = currentMood  // capture mood sebelum reset
        serviceScope.launch { repository.recordPlay(song, totalDuration, mood) }
        songStartTime = 0L
        accumulatedDuration = 0L
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    override fun onDestroy() {
        recordCurrentPlay()
        serviceScope.cancel()
        mediaSession.release()
        player.release()
        super.onDestroy()
    }
}
