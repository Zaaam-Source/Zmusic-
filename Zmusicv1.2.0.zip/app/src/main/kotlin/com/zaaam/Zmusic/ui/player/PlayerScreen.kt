package com.zaaam.Zmusic.ui.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.zaaam.Zmusic.ui.components.AlbumArt
import com.zaaam.Zmusic.util.DownloadState
import com.zaaam.Zmusic.util.toTimeString

private val speedOptions = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    onNavigateBack: () -> Unit
) {
    val queueList by viewModel.queueManager.queue.collectAsState()
    val currentIndex by viewModel.queueManager.currentIndex.collectAsState()
    val song = queueList.getOrNull(currentIndex)

    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val currentPosition by viewModel.currentPosition.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val isShuffled by viewModel.queueManager.isShuffled.collectAsState()
    val currentSpeed by viewModel.queueManager.currentSpeed.collectAsState()

    // Lyrics
    val lyricsState by viewModel.lyricsState.collectAsState()
    val showTranslation by viewModel.showTranslation.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()

    // Download
    val downloadStates by viewModel.downloadManager.states.collectAsState()
    val downloadState = song?.let { downloadStates[it.id] ?: viewModel.downloadManager.getState(it.id) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sedang Diputar") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali")
                    }
                },
                actions = {
                    // FIX: Download button dengan progress indicator yang lebih informatif
                    if (song != null) {
                        when (val ds = downloadState) {
                            is DownloadState.Downloading -> {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.size(48.dp).padding(12.dp)
                                ) {
                                    CircularProgressIndicator(
                                        progress = { if (ds.progress > 0f) ds.progress else 0f },
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.5.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    // Tampilkan persentase kecil di bawah
                                    if (ds.progress > 0f) {
                                        Text(
                                            text = "${(ds.progress * 100).toInt()}%",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(top = 28.dp)
                                        )
                                    }
                                }
                            }
                            is DownloadState.Done -> {
                                IconButton(onClick = { viewModel.deleteDownload(song) }) {
                                    Icon(
                                        Icons.Default.DownloadDone,
                                        "Hapus Download",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            is DownloadState.Error -> {
                                // Error state — tampilkan icon download lagi untuk retry
                                IconButton(onClick = { viewModel.downloadSong(song) }) {
                                    Icon(
                                        Icons.Default.Download,
                                        "Retry Download",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            else -> {
                                IconButton(onClick = { viewModel.downloadSong(song) }) {
                                    Icon(
                                        Icons.Default.Download,
                                        "Download",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(Modifier.height(24.dp))

                // Album Art
                AlbumArt(
                    thumbnailUrl = song?.thumbnailUrl ?: "",
                    size = 260.dp,
                    cornerRadius = 16.dp
                )

                Spacer(Modifier.height(24.dp))

                // Title + Artist
                Text(
                    text = song?.title ?: "Tidak ada lagu",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = song?.artist ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(24.dp))

                // Seek bar
                Slider(
                    value = progress,
                    onValueChange = { viewModel.seekTo(it) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = currentPosition.toTimeString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = (song?.duration ?: 0L).toTimeString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(8.dp))

                // ── Main Controls ──────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Shuffle
                    IconButton(onClick = { viewModel.toggleShuffle() }) {
                        Icon(
                            Icons.Default.Shuffle, "Shuffle",
                            tint = if (isShuffled) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Previous
                    IconButton(onClick = { viewModel.skipPrevious() }) {
                        Icon(Icons.Default.SkipPrevious, "Previous", modifier = Modifier.size(32.dp))
                    }

                    // Play/Pause
                    Box(contentAlignment = Alignment.Center) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(60.dp))
                        } else {
                            IconButton(
                                onClick = { viewModel.togglePlayPause() },
                                modifier = Modifier.size(60.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    modifier = Modifier.size(44.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Next
                    IconButton(onClick = { viewModel.skipNext() }) {
                        Icon(Icons.Default.SkipNext, "Next", modifier = Modifier.size(32.dp))
                    }

                    // Speed indicator button
                    TextButton(
                        onClick = {
                            val nextIndex = (speedOptions.indexOf(currentSpeed) + 1) % speedOptions.size
                            viewModel.setSpeed(speedOptions[nextIndex])
                        }
                    ) {
                        Text(
                            text = "${if (currentSpeed == currentSpeed.toInt().toFloat()) currentSpeed.toInt() else currentSpeed}x",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (currentSpeed != 1f) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // ── 10 Sec Skip Row ────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.seekBackward10() }) {
                        Icon(
                            Icons.Default.FastRewind, "-10s",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "10 detik",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(onClick = { viewModel.seekForward10() }) {
                        Icon(
                            Icons.Default.FastForward, "+10s",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // ── Speed Chips ────────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    speedOptions.forEach { speed ->
                        FilterChip(
                            selected = currentSpeed == speed,
                            onClick = { viewModel.setSpeed(speed) },
                            label = {
                                Text(
                                    text = "${if (speed == speed.toInt().toFloat()) speed.toInt() else speed}x",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                // ── Lyrics Section ─────────────────────────────────────────
                if (song != null) {
                    LyricsSection(
                        song = song,
                        lyricsState = lyricsState,
                        showTranslation = showTranslation,
                        isTranslating = isTranslating,
                        currentPosition = currentPosition,
                        onLoadLyrics = { viewModel.loadLyrics(song) },
                        onToggleTranslation = { viewModel.toggleTranslation(song) }
                    )
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun LyricsSection(
    song: com.zaaam.Zmusic.model.Song,
    lyricsState: LyricsState,
    showTranslation: Boolean,
    isTranslating: Boolean,
    currentPosition: Long,
    onLoadLyrics: () -> Unit,
    onToggleTranslation: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.MusicNote, null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "  Lirik",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                if (lyricsState is LyricsState.Success) {
                    if (isTranslating) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        IconButton(
                            onClick = onToggleTranslation,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Translate, "Terjemahkan",
                                modifier = Modifier.size(20.dp),
                                tint = if (showTranslation) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            when (lyricsState) {
                is LyricsState.Idle -> {
                    TextButton(
                        onClick = onLoadLyrics,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Tampilkan Lirik")
                    }
                }
                is LyricsState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.CenterHorizontally).size(32.dp)
                    )
                }
                is LyricsState.NotFound -> {
                    Text(
                        text = "Lirik tidak ditemukan untuk lagu ini.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                is LyricsState.Error -> {
                    Text(
                        text = lyricsState.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is LyricsState.Success -> {
                    val lyrics = lyricsState.lyrics

                    if (showTranslation && lyricsState.translated != null) {
                        // Tampilkan terjemahan
                        Text(
                            text = lyricsState.translated,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = MaterialTheme.typography.bodyMedium.lineHeight
                        )
                    } else if (lyrics.hasSynced) {
                        // Synced lyrics — highlight baris aktif
                        val activeIndex = lyrics.synced.indexOfLast { it.timeMs <= currentPosition }
                            .coerceAtLeast(0)
                        val listState = rememberLazyListState()

                        LaunchedEffect(activeIndex) {
                            if (activeIndex > 0) listState.animateScrollToItem(
                                (activeIndex - 1).coerceAtLeast(0)
                            )
                        }

                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxWidth().height(220.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            itemsIndexed(lyrics.synced) { index, line ->
                                val isActive = index == activeIndex
                                val textColor by animateColorAsState(
                                    targetValue = if (isActive) MaterialTheme.colorScheme.primary
                                                  else MaterialTheme.colorScheme.onSurfaceVariant,
                                    label = "lyric_color"
                                )
                                Text(
                                    text = line.text.ifBlank { "♪" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                    color = textColor,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                )
                            }
                        }
                    } else {
                        // Plain lyrics
                        Text(
                            text = lyrics.plain,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = MaterialTheme.typography.bodyMedium.lineHeight
                        )
                    }
                }
            }
        }
    }
}
