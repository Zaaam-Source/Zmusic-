package com.zaaam.Zmusic.util

import android.content.Context
import com.zaaam.Zmusic.data.local.SongDao
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.model.entity.toEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed class DownloadState {
    object Idle : DownloadState()
    data class Downloading(val progress: Float = 0f) : DownloadState()  // FIX: progress tracking
    object Done : DownloadState()
    data class Error(val message: String) : DownloadState()
}

@Singleton
class AudioDownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val songDao: SongDao
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    // Map songId → state
    private val _states = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val states: StateFlow<Map<String, DownloadState>> = _states.asStateFlow()

    fun getState(songId: String): DownloadState =
        _states.value[songId] ?: if (isDownloaded(songId)) DownloadState.Done else DownloadState.Idle

    fun isDownloaded(songId: String): Boolean {
        val file = getFile(songId)
        return file.exists() && file.length() > 0
    }

    private fun getFile(songId: String): File =
        File(context.filesDir, "audio_$songId.m4a")

    suspend fun download(
        song: Song,
        getStreamUrl: suspend (String) -> String
    ) = withContext(Dispatchers.IO) {

        // FIX #1: Guard double-tap — jangan download kalau sudah berjalan
        val current = getState(song.id)
        if (current is DownloadState.Downloading) return@withContext

        if (isDownloaded(song.id)) {
            // FIX #2: File ada di disk tapi mungkin DB belum tahu
            // Pastikan song ada di DB dan localPath ter-set
            songDao.insertOrIgnore(song.toEntity())
            songDao.updateLocalPath(song.id, getFile(song.id).absolutePath)
            setState(song.id, DownloadState.Done)
            return@withContext
        }

        setState(song.id, DownloadState.Downloading(0f))

        try {
            val streamUrl = getStreamUrl(song.id)
            val request = Request.Builder().url(streamUrl).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                setState(song.id, DownloadState.Error("Gagal download: ${response.code}"))
                return@withContext
            }

            val file = getFile(song.id)
            val totalBytes = response.body?.contentLength() ?: -1L

            // FIX #3: Progress tracking saat download
            response.body?.byteStream()?.use { input ->
                file.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L

                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        if (totalBytes > 0) {
                            val progress = (totalRead.toFloat() / totalBytes).coerceIn(0f, 1f)
                            setState(song.id, DownloadState.Downloading(progress))
                        }
                    }
                }
            }

            // Verifikasi file berhasil ditulis
            if (!file.exists() || file.length() == 0L) {
                setState(song.id, DownloadState.Error("File kosong setelah download"))
                return@withContext
            }

            // FIX #4 (KRITIS): INSERT song ke DB dulu, BARU update localPath
            // Tanpa ini, UPDATE ... WHERE id = :id match 0 rows karena song belum ada di tabel
            songDao.insertOrIgnore(song.toEntity())
            songDao.updateLocalPath(song.id, file.absolutePath)
            setState(song.id, DownloadState.Done)

        } catch (e: Exception) {
            // Hapus file partial kalau gagal
            val file = getFile(song.id)
            if (file.exists()) file.delete()
            setState(song.id, DownloadState.Error("Download gagal: ${e.message}"))
        }
    }

    fun deleteDownload(songId: String) {
        val file = getFile(songId)
        if (file.exists()) file.delete()
        // Reset localPath di DB — dilakukan di repository
        setState(songId, DownloadState.Idle)
    }

    private fun setState(songId: String, state: DownloadState) {
        _states.value = _states.value.toMutableMap().apply { put(songId, state) }
    }
}
