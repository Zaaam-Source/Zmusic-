package com.zaaam.Zmusic

import android.app.Application
import com.zaaam.Zmusic.data.NewPipeDownloader
import dagger.hilt.android.HiltAndroidApp
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import javax.inject.Inject

@HiltAndroidApp
class ZmusicApp : Application() {

    @Inject lateinit var newPipeDownloader: NewPipeDownloader

    override fun onCreate() {
        super.onCreate()

        // FIX: Pakai overload init(Downloader, Localization, ContentCountry)
        // v0.25.2 tidak punya setLocalization()/setContentCountry() terpisah.
        // Localization dan ContentCountry WAJIB untuk Kiosk/Trending API YouTube.
        NewPipe.init(
            newPipeDownloader,
            Localization("id", "ID"),
            ContentCountry("ID")
        )
    }
}
