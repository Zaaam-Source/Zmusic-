package com.zaaam.Zmusic.model

data class LyricLine(
    val timeMs: Long,
    val text: String
)

data class Lyrics(
    val plain: String,
    val synced: List<LyricLine> = emptyList()
) {
    val hasSynced: Boolean get() = synced.isNotEmpty()
}

enum class Mood(val emoji: String, val label: String, val queries: List<String>) {
    HAPPY("😊", "Happy", listOf("lagu happy vibes ceria", "happy songs upbeat")),
    SAD("😢", "Sad", listOf("lagu sedih galau terbaru", "sad song Indonesia")),
    ENERGETIC("⚡", "Energetic", listOf("lagu semangat workout hype", "energetic music pump up")),
    CHILL("😌", "Chill", listOf("lagu santai lofi indonesia", "chill vibes relaxing")),
    ROMANCE("❤️", "Romance", listOf("lagu romantis terbaik", "love song romantic")),
    HYPE("🔥", "Hype", listOf("lagu party hits indonesia", "hype music trending"))
}
