package com.zaaam.Zmusic.data

import android.net.Uri
import com.zaaam.Zmusic.model.LyricLine
import com.zaaam.Zmusic.model.Lyrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LyricsRepository @Inject constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // ── LRCLIB: Fetch Lyrics ───────────────────────────────────────────────

    suspend fun getLyrics(title: String, artist: String): Lyrics? = withContext(Dispatchers.IO) {
        try {
            val url = "https://lrclib.net/api/get?" +
                    "artist_name=${Uri.encode(artist)}&track_name=${Uri.encode(title)}"

            val request = Request.Builder()
                .url(url)
                .header("Lrclib-Client", "Zmusic Android v1.0")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext null

            val body = response.body?.string() ?: return@withContext null
            val json = JSONObject(body)

            val plain = if (json.has("plainLyrics") && !json.isNull("plainLyrics"))
                json.getString("plainLyrics") else ""

            val syncedRaw = if (json.has("syncedLyrics") && !json.isNull("syncedLyrics"))
                json.getString("syncedLyrics") else ""

            if (plain.isBlank() && syncedRaw.isBlank()) return@withContext null

            val synced = parseLrc(syncedRaw)

            Lyrics(plain = plain, synced = synced)

        } catch (_: Exception) {
            null
        }
    }

    // ── LRC Parser ─────────────────────────────────────────────────────────

    private fun parseLrc(lrc: String): List<LyricLine> {
        if (lrc.isBlank()) return emptyList()
        val result = mutableListOf<LyricLine>()
        val pattern = Regex("""^\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)""")

        lrc.lines().forEach { line ->
            val match = pattern.find(line.trim()) ?: return@forEach
            val (min, sec, ms, text) = match.destructured
            val timeMs = min.toLong() * 60_000 +
                         sec.toLong() * 1_000 +
                         (if (ms.length == 2) ms.toLong() * 10 else ms.toLong())
            result.add(LyricLine(timeMs = timeMs, text = text.trim()))
        }

        return result.sortedBy { it.timeMs }
    }

    // ── MyMemory: Translate Lyrics ─────────────────────────────────────────

    suspend fun translateLyrics(text: String, targetLang: String = "id"): String? =
        withContext(Dispatchers.IO) {
            try {
                val encoded = Uri.encode(text)
                val url = "https://api.mymemory.translated.net/get?q=$encoded&langpair=en|$targetLang"

                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()
                if (!response.isSuccessful) return@withContext fallbackTranslate(text, targetLang)

                val body = response.body?.string() ?: return@withContext null
                val json = JSONObject(body)

                val responseData = json.optJSONObject("responseData")
                val translated = responseData?.optString("translatedText")

                if (translated.isNullOrBlank() || translated == text) {
                    fallbackTranslate(text, targetLang)
                } else {
                    translated
                }
            } catch (_: Exception) {
                fallbackTranslate(text, targetLang)
            }
        }

    // ── Lingva: Fallback Translate ─────────────────────────────────────────

    private fun fallbackTranslate(text: String, targetLang: String): String? {
        return try {
            val encoded = Uri.encode(text)
            val url = "https://lingva.ml/api/v1/en/$targetLang/$encoded"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            json.optString("translation").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
