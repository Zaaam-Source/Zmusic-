package com.zaaam.Zmusic.ui.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaaam.Zmusic.model.Mood
import com.zaaam.Zmusic.model.entity.MoodStatResult
import com.zaaam.Zmusic.ui.components.AlbumArt
import com.zaaam.Zmusic.util.toHoursMinutesString

// Helper: Map mood string ke Mood enum
private fun getMoodEnum(moodName: String): Mood? =
    Mood.values().firstOrNull { it.name.equals(moodName, ignoreCase = true) }

// Warna gradient untuk mood cards di stats
private val moodStatsColors = mapOf(
    Mood.HAPPY     to listOf(Color(0xFFFFF176), Color(0xFFFFD54F)),
    Mood.SAD       to listOf(Color(0xFF90CAF9), Color(0xFF5C6BC0)),
    Mood.ENERGETIC to listOf(Color(0xFFFF8A65), Color(0xFFE53935)),
    Mood.CHILL     to listOf(Color(0xFFA5D6A7), Color(0xFF26A69A)),
    Mood.ROMANCE   to listOf(Color(0xFFF48FB1), Color(0xFFEC407A)),
    Mood.HYPE      to listOf(Color(0xFFCE93D8), Color(0xFF8E24AA))
)

private val moodBarColors = mapOf(
    Mood.HAPPY     to Color(0xFFFFD54F),
    Mood.SAD       to Color(0xFF5C6BC0),
    Mood.ENERGETIC to Color(0xFFE53935),
    Mood.CHILL     to Color(0xFF26A69A),
    Mood.ROMANCE   to Color(0xFFEC407A),
    Mood.HYPE      to Color(0xFF8E24AA)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(viewModel: StatsViewModel) {
    val totalPlays by viewModel.totalPlays.collectAsState()
    val totalDuration by viewModel.totalDuration.collectAsState()
    val topSongs by viewModel.topSongs.collectAsState()
    val topArtists by viewModel.topArtists.collectAsState()
    val moodDistribution by viewModel.moodDistribution.collectAsState()
    val recentMood by viewModel.recentMood.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Statistik") })

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // ── Summary Cards ──────────────────────────────────────────────
            Row {
                Card(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "$totalPlays",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Lagu diputar",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Card(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = totalDuration.toHoursMinutesString(),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Didengarkan",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // ── NEW: Mood Detector Section ─────────────────────────────────
            Spacer(Modifier.height(24.dp))
            MoodDetectorSection(
                moodDistribution = moodDistribution,
                recentMood = recentMood
            )

            // ── Top Songs ──────────────────────────────────────────────────
            if (topSongs.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(
                    "Lagu Favoritmu",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                topSongs.forEach { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArt(thumbnailUrl = song.thumbnailUrl, size = 48.dp)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp)
                        ) {
                            Text(song.title, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                song.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            "${song.playCount}x",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // ── Top Artists ────────────────────────────────────────────────
            if (topArtists.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(
                    "Artis Favoritmu",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                topArtists.forEach { artist ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.MusicNote,
                            null,
                            modifier = Modifier
                                .size(48.dp)
                                .padding(8.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            artist.artist,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "${artist.playCount}x",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ── Mood Detector Section ──────────────────────────────────────────────────

@Composable
private fun MoodDetectorSection(
    moodDistribution: List<MoodStatResult>,
    recentMood: MoodStatResult?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Mood, null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Mood Detector",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(Modifier.height(16.dp))

            if (moodDistribution.isEmpty()) {
                // Belum ada data mood
                Text(
                    text = "Belum ada data mood.\nDengarkan lagu dari tab Mood untuk mulai tracking!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                // ── Mood Terakhir (Recent) ─────────────────────────────────
                if (recentMood != null) {
                    val mood = getMoodEnum(recentMood.mood)
                    if (mood != null) {
                        RecentMoodCard(mood = mood)
                        Spacer(Modifier.height(16.dp))
                    }
                }

                // ── Mood Paling Sering ─────────────────────────────────────
                val topMood = moodDistribution.firstOrNull()
                if (topMood != null) {
                    val mood = getMoodEnum(topMood.mood)
                    if (mood != null) {
                        Text(
                            text = "Mood Paling Sering",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = mood.emoji,
                                fontSize = 28.sp
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = mood.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${topMood.playCount} lagu diputar",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // ── Distribusi Mood (bar chart) ────────────────────────────
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Distribusi Mood",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))

                val maxCount = moodDistribution.maxOf { it.playCount }

                moodDistribution.forEach { stat ->
                    val mood = getMoodEnum(stat.mood)
                    val fraction = stat.playCount.toFloat() / maxCount
                    val barColor = mood?.let { moodBarColors[it] }
                        ?: MaterialTheme.colorScheme.primary

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = mood?.emoji ?: "?",
                            fontSize = 18.sp,
                            modifier = Modifier.width(28.dp)
                        )
                        Text(
                            text = mood?.label ?: stat.mood,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.width(70.dp)
                        )
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier
                                .weight(1f)
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = barColor,
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                            strokeCap = StrokeCap.Round
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${stat.playCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(28.dp),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentMoodCard(mood: Mood) {
    val colors = moodStatsColors[mood] ?: listOf(Color.Gray, Color.DarkGray)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(colors))
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "Mood Terkini",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.8f),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = mood.emoji,
                        fontSize = 36.sp
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = mood.label,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Berdasarkan lagu terakhir kamu",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }
    }
}
