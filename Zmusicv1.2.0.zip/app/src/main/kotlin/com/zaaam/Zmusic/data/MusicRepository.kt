package com.zaaam.Zmusic.data

import com.zaaam.Zmusic.data.local.PlayHistoryDao
import com.zaaam.Zmusic.data.local.PlaylistDao
import com.zaaam.Zmusic.data.local.SongDao
import com.zaaam.Zmusic.model.Mood
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.model.entity.MoodStatResult
import com.zaaam.Zmusic.model.entity.PlayHistoryEntity
import com.zaaam.Zmusic.model.entity.PlaylistEntity
import com.zaaam.Zmusic.model.entity.PlaylistSongCrossRef
import com.zaaam.Zmusic.model.entity.PlaylistWithSongs
import com.zaaam.Zmusic.model.entity.TopArtistResult
import com.zaaam.Zmusic.model.entity.TopSongResult
import com.zaaam.Zmusic.model.entity.toEntity
import com.zaaam.Zmusic.model.entity.toSong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MusicRepository @Inject constructor(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val playHistoryDao: PlayHistoryDao
) {

    // ── NewPipe: Helper ────────────────────────────────────────────────────

    private fun extractVideoId(url: String): String? =
        Regex("""(?:v=|youtu\.be/|/v/)([\w-]{11})""").find(url)?.groupValues?.get(1)

    private fun StreamInfoItem.toSong(): Song? {
        val videoId = extractVideoId(url) ?: return null
        return Song(
            id = videoId,
            title = name ?: return null,
            artist = uploaderName?.removeSuffix(" - Topic") ?: "Unknown",
            thumbnailUrl = thumbnails.maxByOrNull { it.height }?.url ?: "",
            duration = duration * 1000L
        )
    }

    // ── NewPipe: Search ────────────────────────────────────────────────────

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val searchHandler = youtubeService.searchQHFactory
            .fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), "")
        val searchInfo = SearchInfo.getInfo(youtubeService, searchHandler)

        searchInfo.relatedItems
            .filterIsInstance<StreamInfoItem>()
            .mapNotNull { it.toSong() }
            .distinctBy { it.id }
            .take(20)
    }

    // ── NewPipe: Stream URL ────────────────────────────────────────────────

    suspend fun getStreamUrl(videoId: String): String = withContext(Dispatchers.IO) {
        // Cek local path dulu
        val localPath = songDao.getLocalPath(videoId)
        if (localPath != null && File(localPath).exists()) return@withContext localPath

        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val streamInfo = StreamInfo.getInfo(
            youtubeService,
            "https://www.youtube.com/watch?v=$videoId"
        )

        streamInfo.audioStreams
            .filter { it.content != null }
            .maxByOrNull { it.averageBitrate }
            ?.content
            ?: throw Exception("Tidak ada stream audio tersedia untuk video ini")
    }

    // ── NewPipe: Discovery ─────────────────────────────────────────────────

    suspend fun getDiscovery(): List<Song> = withContext(Dispatchers.IO) {
        try {
            val kiosk = getDiscoveryFromKiosk()
            if (kiosk.isNotEmpty()) return@withContext kiosk
        } catch (_: Exception) { }
        getDiscoveryFromSearch()
    }

    private suspend fun getDiscoveryFromKiosk(): List<Song> {
        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val kioskList = youtubeService.kioskList
        val kioskId = when {
            "Trending" in kioskList.availableKiosks -> "Trending"
            else -> kioskList.defaultKioskId
        }
        val kioskExtractor = kioskList.getExtractorById(kioskId, null)
        kioskExtractor.fetchPage()
        return kioskExtractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter { it.duration in 30..900 }
            .mapNotNull { it.toSong() }
            .distinctBy { it.id }
            .take(30)
    }

    private suspend fun getDiscoveryFromSearch(): List<Song> = coroutineScope {
        val queries = listOf("lagu populer 2025", "top hits indonesia", "musik trending terbaru")
        queries.map { query ->
            async {
                try {
                    val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
                    val searchHandler = youtubeService.searchQHFactory
                        .fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), "")
                    val searchInfo = SearchInfo.getInfo(youtubeService, searchHandler)
                    searchInfo.relatedItems
                        .filterIsInstance<StreamInfoItem>()
                        .mapNotNull { it.toSong() }
                } catch (_: Exception) { emptyList() }
            }
        }.awaitAll().flatten().distinctBy { it.id }.take(30)
    }

    // ── Mood-based Search ──────────────────────────────────────────────────

    suspend fun searchByMood(mood: Mood): List<Song> = coroutineScope {
        mood.queries.map { query ->
            async {
                try { search(query) } catch (_: Exception) { emptyList() }
            }
        }.awaitAll().flatten().distinctBy { it.id }.take(25)
    }

    // ── NEW: Dynamic Mood Detection ────────────────────────────────────────
    // Analisis judul + artis lagu untuk deteksi mood secara otomatis.
    // Dipakai untuk SEMUA lagu yang diputar dari tab manapun.

    private val moodKeywords: Map<Mood, List<String>> = mapOf(
        Mood.HAPPY to listOf(
            "happy", "ceria", "senang", "bahagia", "gembira", "senyum",
            "sunshine", "joy", "riang", "fun", "cheerful", "bright",
            "wonderful", "smiling", "good day", "good life", "semangat pagi",
            "hari cerah", "berbunga", "tawa"
        ),
        Mood.SAD to listOf(
            "sedih", "galau", "kecewa", "patah hati", "menangis", "tangis",
            "lonely", "broken", "tears", "cry", "hurt", "sakit hati",
            "perih", "kehilangan", "hilang", "rindu", "sendiri",
            "luka", "duka", "hancur", "sad", "heartbreak", "menyesal",
            "sesal", "pilu", "derita"
        ),
        Mood.ENERGETIC to listOf(
            "semangat", "workout", "gym", "power", "strong", "energy",
            "pump", "run", "sport", "fight", "lari", "olahraga",
            "kuat", "bangkit", "energetic", "beast", "fire", "unstoppable",
            "warrior", "pejuang", "rock", "metal"
        ),
        Mood.CHILL to listOf(
            "santai", "lofi", "relax", "tenang", "calm", "mellow",
            "easy", "chill", "sore", "malam", "tidur", "sleep",
            "dreamy", "peaceful", "slow", "acoustic", "lullaby",
            "senja", "damai", "hening", "jazz", "bossa"
        ),
        Mood.ROMANCE to listOf(
            "cinta", "sayang", "romantis", "love", "kasih", "jatuh cinta",
            "miss you", "miss", "heart", "dear", "darling", "sweetheart",
            "kekasih", "pacar", "valentine", "duet", "berdua",
            "mesra", "peluk", "kiss", "satu hati", "belahan"
        ),
        Mood.HYPE to listOf(
            "party", "hype", "dance", "dj", "rave", "club",
            "turn up", "lit", "bass", "drop", "edm", "remix",
            "dugem", "goyang", "joget", "disco", "nonstop",
            "trending", "viral", "tiktok"
        )
    )

    /**
     * Deteksi mood dari metadata lagu (title + artist).
     * Mengembalikan nama Mood (String) atau null kalau tidak cocok.
     * Score dihitung berdasarkan jumlah keyword match.
     */
    fun detectMood(song: Song): String? {
        val text = "${song.title} ${song.artist}".lowercase()

        var bestMood: Mood? = null
        var bestScore = 0

        for ((mood, keywords) in moodKeywords) {
            var score = 0
            for (keyword in keywords) {
                if (text.contains(keyword)) {
                    // Keyword lebih panjang → bobot lebih tinggi (lebih spesifik)
                    score += keyword.length
                }
            }
            if (score > bestScore) {
                bestScore = score
                bestMood = mood
            }
        }

        // Minimal score 3 agar tidak false positive dari keyword 1-2 huruf
        return if (bestScore >= 3) bestMood?.name else null
    }

    // ── Offline: Download Management ───────────────────────────────────────

    suspend fun clearLocalPath(songId: String) {
        songDao.updateLocalPath(songId, null)
    }

    fun getDownloadedSongs(): Flow<List<Song>> =
        songDao.getDownloadedSongs().map { list -> list.map { it.toSong() } }

    // ── Playlist ───────────────────────────────────────────────────────────

    suspend fun createPlaylist(name: String): Long =
        playlistDao.insert(PlaylistEntity(name = name))

    suspend fun addToPlaylist(playlistId: Long, song: Song) {
        songDao.insertOrIgnore(song.toEntity())
        val position = playlistDao.getSongCount(playlistId)
        playlistDao.addSong(PlaylistSongCrossRef(playlistId, song.id, position))
    }

    suspend fun removeFromPlaylist(playlistId: Long, songId: String) =
        playlistDao.removeSong(playlistId, songId)

    fun getAllPlaylists(): Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()

    fun getPlaylistWithSongs(playlistId: Long): Flow<PlaylistWithSongs> =
        playlistDao.getPlaylistWithSongs(playlistId)

    suspend fun deletePlaylist(playlistId: Long) = playlistDao.delete(playlistId)

    // ── Play History / Stats ───────────────────────────────────────────────

    /**
     * Record play dengan mood detection DINAMIS:
     * - Kalau mood sudah dikasih (dari MoodScreen) → pakai itu
     * - Kalau mood null (dari Home/Search/Library/Playlist) → auto-detect dari judul+artis
     */
    suspend fun recordPlay(song: Song, durationListened: Long, mood: String? = null) {
        if (durationListened < 10_000) return
        val resolvedMood = mood ?: detectMood(song)
        playHistoryDao.insert(
            PlayHistoryEntity(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                thumbnailUrl = song.thumbnailUrl,
                durationListened = durationListened,
                mood = resolvedMood
            )
        )
    }

    fun getTotalPlays(): Flow<Int> = playHistoryDao.getTotalPlays()
    fun getTotalDuration(): Flow<Long?> = playHistoryDao.getTotalDuration()
    fun getTopSongs(limit: Int = 5): Flow<List<TopSongResult>> = playHistoryDao.getTopSongs(limit)
    fun getTopArtists(limit: Int = 3): Flow<List<TopArtistResult>> = playHistoryDao.getTopArtists(limit)

    // Mood stats
    fun getMoodDistribution(): Flow<List<MoodStatResult>> = playHistoryDao.getMoodDistribution()
    fun getRecentMood(): Flow<MoodStatResult?> = playHistoryDao.getRecentMood()
}
