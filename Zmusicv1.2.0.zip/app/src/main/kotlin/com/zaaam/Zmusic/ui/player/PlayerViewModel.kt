package com.zaaam.Zmusic.ui.player

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.zaaam.Zmusic.data.LyricsRepository
import com.zaaam.Zmusic.data.MusicRepository
import com.zaaam.Zmusic.model.Lyrics
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.service.MusicService
import com.zaaam.Zmusic.util.AudioDownloadManager
import com.zaaam.Zmusic.util.DownloadState
import com.zaaam.Zmusic.util.QueueManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class LyricsState {
    object Idle : LyricsState()
    object Loading : LyricsState()
    data class Success(val lyrics: Lyrics, val translated: String? = null) : LyricsState()
    object NotFound : LyricsState()
    data class Error(val message: String) : LyricsState()
}

@HiltViewModel
class PlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    val queueManager: QueueManager,
    private val lyricsRepository: LyricsRepository,
    private val musicRepository: MusicRepository,
    val downloadManager: AudioDownloadManager
) : ViewModel() {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Lyrics
    private val _lyricsState = MutableStateFlow<LyricsState>(LyricsState.Idle)
    val lyricsState: StateFlow<LyricsState> = _lyricsState.asStateFlow()

    private val _showTranslation = MutableStateFlow(false)
    val showTranslation: StateFlow<Boolean> = _showTranslation.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var lastSongId: String? = null

    init {
        connectToService()
        startProgressUpdate()
        observeCurrentSong()
    }

    private fun connectToService() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicService::class.java)
        )
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _isPlaying.value = isPlaying
                    if (isPlaying) _isLoading.value = false
                }
                override fun onPlaybackStateChanged(state: Int) {
                    _isLoading.value = state == Player.STATE_BUFFERING
                    if (state == Player.STATE_ENDED) {
                        _isPlaying.value = false
                        _progress.value = 0f
                    }
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    _errorMessage.value = "Gagal memutar lagu, coba lagi"
                    _isLoading.value = false
                    _isPlaying.value = false
                }
            })
        }, MoreExecutors.directExecutor())
    }

    private fun startProgressUpdate() {
        viewModelScope.launch {
            while (true) {
                delay(500)
                val ctrl = controller ?: continue
                val duration = ctrl.duration
                val position = ctrl.currentPosition
                if (duration > 0) {
                    _progress.value = position.toFloat() / duration
                    _currentPosition.value = position
                }
            }
        }
    }

    // Auto-load lyrics saat lagu ganti
    private fun observeCurrentSong() {
        viewModelScope.launch {
            queueManager.currentIndex.collect {
                val song = queueManager.current() ?: return@collect
                if (song.id != lastSongId) {
                    lastSongId = song.id
                    _lyricsState.value = LyricsState.Idle
                    _showTranslation.value = false
                }
            }
        }
    }

    // FIX: Tambah parameter mood untuk diteruskan ke QueueManager → MusicService
    fun playSong(song: Song, queue: List<Song> = listOf(song), mood: String? = null) {
        _errorMessage.value = null
        _isLoading.value = true
        _lyricsState.value = LyricsState.Idle
        _showTranslation.value = false
        queueManager.setQueue(queue, queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0), mood)
        queueManager.requestPlay(song, userInitiated = true, mood = mood)
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
    }

    fun seekTo(fraction: Float) {
        val ctrl = controller ?: return
        val duration = ctrl.duration
        if (duration > 0) ctrl.seekTo((fraction * duration).toLong())
    }

    // 10 detik skip
    fun seekForward10() {
        val ctrl = controller ?: return
        ctrl.seekTo((ctrl.currentPosition + 10_000).coerceAtMost(ctrl.duration.coerceAtLeast(0)))
    }

    fun seekBackward10() {
        val ctrl = controller ?: return
        ctrl.seekTo((ctrl.currentPosition - 10_000).coerceAtLeast(0))
    }

    fun skipNext() {
        val next = queueManager.next() ?: return
        _isLoading.value = true
        queueManager.requestPlay(next, userInitiated = true)
    }

    fun skipPrevious() {
        val ctrl = controller
        if (ctrl != null && ctrl.currentPosition > 3000) {
            ctrl.seekTo(0)
        } else {
            val prev = queueManager.previous() ?: return
            _isLoading.value = true
            queueManager.requestPlay(prev, userInitiated = true)
        }
    }

    fun toggleShuffle() = queueManager.toggleShuffle()

    // Speed control
    fun setSpeed(speed: Float) = queueManager.setSpeed(speed)

    // Load lyrics
    fun loadLyrics(song: Song) {
        if (_lyricsState.value is LyricsState.Success || _lyricsState.value is LyricsState.Loading) return
        viewModelScope.launch {
            _lyricsState.value = LyricsState.Loading
            val lyrics = lyricsRepository.getLyrics(song.title, song.artist)
            _lyricsState.value = if (lyrics != null) LyricsState.Success(lyrics)
                                  else LyricsState.NotFound
        }
    }

    // Toggle translation
    fun toggleTranslation(song: Song) {
        val state = _lyricsState.value as? LyricsState.Success ?: return
        if (state.translated != null) {
            _showTranslation.value = !_showTranslation.value
            return
        }
        // Belum ada terjemahan — fetch dulu
        viewModelScope.launch {
            _isTranslating.value = true
            val textToTranslate = if (state.lyrics.hasSynced)
                state.lyrics.synced.joinToString("\n") { it.text }
            else
                state.lyrics.plain

            val translated = lyricsRepository.translateLyrics(textToTranslate)
            _isTranslating.value = false
            _lyricsState.value = state.copy(translated = translated ?: "Terjemahan tidak tersedia")
            _showTranslation.value = true
        }
    }

    // FIX: Download lagu offline — cek state dulu sebelum mulai
    fun downloadSong(song: Song) {
        val currentState = downloadManager.getState(song.id)
        if (currentState is DownloadState.Downloading || currentState is DownloadState.Done) return
        viewModelScope.launch {
            downloadManager.download(song) { id -> musicRepository.getStreamUrl(id) }
        }
    }

    fun deleteDownload(song: Song) {
        viewModelScope.launch {
            downloadManager.deleteDownload(song.id)
            musicRepository.clearLocalPath(song.id)
        }
    }

    fun clearError() { _errorMessage.value = null }

    override fun onCleared() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
