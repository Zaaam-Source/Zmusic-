package com.zaaam.Zmusic.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.zaaam.Zmusic.model.entity.PlayHistoryEntity
import com.zaaam.Zmusic.model.entity.PlaylistEntity
import com.zaaam.Zmusic.model.entity.PlaylistSongCrossRef
import com.zaaam.Zmusic.model.entity.SongEntity

@Database(
    entities = [
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        PlayHistoryEntity::class
    ],
    version = 3,            // BUMPED: v2→v3 tambah kolom mood di play_history
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun playHistoryDao(): PlayHistoryDao

    companion object {
        // Migration v1 → v2: tambah kolom localPath nullable di songs
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE songs ADD COLUMN localPath TEXT")
            }
        }

        // Migration v2 → v3: tambah kolom mood nullable di play_history
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE play_history ADD COLUMN mood TEXT")
            }
        }
    }
}
