package com.zaaam.Zmusic.util

import com.zaaam.Zmusic.model.Song
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

// FIX: Tambah field mood agar MusicService bisa record mood context
data class PlayRequest(
    val song: Song,
    val userInitiated: Boolean = true,
    val mood: String? = null
)

@Singleton
class QueueManager @Inject constructor() {

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isShuffled = MutableStateFlow(false)
    val isShuffled: StateFlow<Boolean> = _isShuffled.asStateFlow()

    private val _playCommand = MutableSharedFlow<PlayRequest>(extraBufferCapacity = 1)
    val playCommand: SharedFlow<PlayRequest> = _playCommand.asSharedFlow()

    // Speed command untuk dikirim ke MusicService
    private val _speedCommand = MutableSharedFlow<Float>(extraBufferCapacity = 1)
    val speedCommand: SharedFlow<Float> = _speedCommand.asSharedFlow()

    private val _currentSpeed = MutableStateFlow(1f)
    val currentSpeed: StateFlow<Float> = _currentSpeed.asStateFlow()

    // NEW: Mood context — disimpan saat setQueue dari MoodScreen
    // Digunakan oleh MusicService saat recordPlay untuk semua lagu dalam queue ini
    private val _currentMood = MutableStateFlow<String?>(null)
    val currentMood: StateFlow<String?> = _currentMood.asStateFlow()

    private var originalQueue: List<Song> = emptyList()

    fun setQueue(songs: List<Song>, startIndex: Int = 0, mood: String? = null) {
        originalQueue = songs
        _queue.value = songs.toMutableList()
        _currentIndex.value = startIndex.coerceIn(0, (songs.size - 1).coerceAtLeast(0))
        _isShuffled.value = false
        _currentMood.value = mood
    }

    fun requestPlay(song: Song, userInitiated: Boolean = true, mood: String? = null) {
        _playCommand.tryEmit(PlayRequest(song, userInitiated, mood ?: _currentMood.value))
    }

    // Set playback speed
    fun setSpeed(speed: Float) {
        _currentSpeed.value = speed
        _speedCommand.tryEmit(speed)
    }

    fun toggleShuffle() {
        val currentSong = current()
        if (_isShuffled.value) {
            _queue.value = originalQueue
            _currentIndex.value = originalQueue.indexOfFirst { it.id == currentSong?.id }
                .coerceAtLeast(0)
        } else {
            val rest = _queue.value.filter { it.id != currentSong?.id }.shuffled()
            _queue.value = listOfNotNull(currentSong) + rest
            _currentIndex.value = 0
        }
        _isShuffled.value = !_isShuffled.value
    }

    fun next(): Song? {
        val q = _queue.value
        if (q.isEmpty()) return null
        return if (_currentIndex.value < q.size - 1) {
            _currentIndex.value++
            current()
        } else null
    }

    fun previous(): Song? {
        if (_currentIndex.value > 0) _currentIndex.value--
        return current()
    }

    fun current(): Song? = _queue.value.getOrNull(_currentIndex.value)
    fun hasNext(): Boolean = _currentIndex.value < _queue.value.size - 1
    fun hasPrevious(): Boolean = _currentIndex.value > 0
}
