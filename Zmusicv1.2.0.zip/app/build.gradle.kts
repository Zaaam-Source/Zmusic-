plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.zaaam.Zmusic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zaaam.Zmusic"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true  // WAJIB untuk minSdk < 33
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Core Library Desugaring — WAJIB untuk minSdk 26
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // AppCompat
    implementation("androidx.appcompat:appcompat:1.7.0")

    // Media3 (ExoPlayer)
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Hilt
    implementation("com.google.dagger:hilt-android:2.51")
    ksp("com.google.dagger:hilt-compiler:2.51")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    // NewPipeExtractor v0.25.2
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.25.2")

    // OkHttp 4.12.0 — DOWNGRADE dari 5.3.2
    // okhttp 5.3.2 menarik okio 3.16.4 (dikompilasi Kotlin 2.2.0) yang menyebabkan
    // KSP 2.0.21 crash karena tidak bisa baca metadata Kotlin 2.2.0.
    // okhttp 4.12.0 menarik okio 3.6.0 (Kotlin 1.9.x) → fully compatible dengan KSP 2.0.21.
    // API okhttp3.* identik antara versi 4.x dan 5.x, NewPipeDownloader.kt tidak perlu diubah.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Image loader
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Compose BOM
    implementation(platform("androidx.compose:compose-bom:2024.04.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
